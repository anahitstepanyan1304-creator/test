﻿using Microsoft.AspNetCore.Mvc;

namespace ApiLab;

public class ParcelUpdate
{
    public string Status { get; set; } = "";
}
 
[ApiController]
[Route("api/[controller]")]
public class ParcelsController : ControllerBase
{
    [HttpPost("{id}")]
    public IActionResult Update(int id, bool notify,
        [FromHeader(Name = "X-Api-Key")] string key,
        ParcelUpdate update)
    {
        return Ok(new { id, notify, key, update.Status });
    }
    [HttpPost("noid")]
    public IActionResult UpdateNoId(
        int id,
        bool notify,
        ParcelUpdate update)
    {
        return Ok(new
        {
            id,
            notify,
            update.Status
        });
    }

}
