﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace ApiLab;

public class Ticket
{
    public int Id { get; set; }
    public string Seat { get; set; } = "";
    public int Price { get; set; }
    public bool IsPaid { get; set; }
}
 
public class CreateTicketRequest
{
    [Required]
    public string Seat { get; set; } = "";

    [Range(1, 100000)]
    public int Price { get; set; }
}


[ApiController]
[Route("api/[controller]")]
public class TicketsController : ControllerBase
{
    private static readonly List<Ticket> Tickets = new();


    [HttpPost]
    public ActionResult<Ticket> Create(CreateTicketRequest request)
    {
        var ticket = new Ticket
        {
            Id = Tickets.Count + 1,
            Seat = request.Seat,
            Price = request.Price,
            IsPaid = false
        };

        Tickets.Add(ticket);

        return CreatedAtAction(
            nameof(Get),
            new { id = ticket.Id },
            ticket);
    }


    [HttpGet("{id:int}")]
    public ActionResult<Ticket> Get(int id)
    {
        var ticket = Tickets.FirstOrDefault(t => t.Id == id);

        if (ticket is null)
        {
            return NotFound();
        }

        return Ok(ticket);
    }
}