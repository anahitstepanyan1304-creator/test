﻿using Microsoft.AspNetCore.Mvc;

namespace ApiLab.Controllers;

[ApiController]
[Route("api/spots")]

public class SpotsController:ControllerBase
{
    [HttpGet("{id:int}")]
    public string A(int id) => $"A: spot {id}";
 
    [HttpGet("level/{n:min(1)}")]
    public string B(int n) => $"B: level {n}";
 
    [HttpGet("ticket/{code:guid}")]
    public string C(Guid code) => $"C: ticket {code}";
 
    [HttpGet("zone/{name?}")]
    public string D(string? name) => $"D: zone [{name}]";
}
