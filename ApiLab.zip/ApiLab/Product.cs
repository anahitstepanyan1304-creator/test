﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace ApiLab;

public class Product
{
    [Required]
    [StringLength(10)]
    public string Name { get; set; } = "";
 
    [Range(0, 100)]
    public int Quantity { get; set; }
}
 
[ApiController]
[Route("api/[controller]")]
public class ProductsController : ControllerBase
{
    [HttpPost]
    public IActionResult Create(Product product) => Ok(product);
}
