﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace ApiLab;

public class CreateBookingRequest
{
    [Required]
    [StringLength(30)]
    public string Guest { get; set; } = "";

    [Range(1, 14)]
    public int Nights { get; set; }
}

public class Booking
{
    public int Id { get; set; }
    public int RoomId { get; set; }
    public string Guest { get; set; } = "";
    public int Nights { get; set; }
}

[ApiController]
[Route("api/rooms/{roomId:min(1)}/bookings")]
public class RoomBookingsController : ControllerBase
{
    private static readonly List<Booking> Bookings = new();

    [HttpPost]
    public ActionResult<Booking> Create(
        int roomId,
        [FromQuery] bool notify,
        [FromHeader(Name = "X-Api-Key")] string key,
        CreateBookingRequest request)
    {
        var booking = new Booking
        {
            Id = Bookings.Count + 1,
            RoomId = roomId,
            Guest = request.Guest,
            Nights = request.Nights
        };

        Bookings.Add(booking);

        if (notify)
        {
            Console.WriteLine($"Notification requested for {request.Guest}");
        }

        return CreatedAtAction(
            nameof(GetById),
            new { roomId = booking.RoomId, id = booking.Id },
            booking);
    }

    [HttpGet("{id:min(1)}")]
    public ActionResult<Booking> GetById(int roomId, int id)
    {
        var booking = Bookings.FirstOrDefault(
            b => b.RoomId == roomId && b.Id == id);

        if (booking == null)
        {
            return NotFound();
        }

        return Ok(booking);
    }
}