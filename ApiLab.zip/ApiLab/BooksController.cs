﻿using Microsoft.AspNetCore.Mvc;

namespace ApiLab;
[ApiController]
[Route("api/[controller]")]

public class BooksController:ControllerBase
{
    private static readonly List<string> Books =
        new() { "Basics", "Networking", "Algorithms" };
 
    [HttpGet]
    public ActionResult<List<string>> GetAll() => Books;
    
    [HttpGet("{id}")]
    public ActionResult<string> GetById(int id)
    {
        if (id<1  ||  id > Books.Count)
        {
            return NotFound();
        }
        return Books[id-1];
    }
    [HttpGet("{title}")]
    public ActionResult<string> GetByTitle(string title)
    {
        var book = Books.FirstOrDefault(
            b => b.Equals(title, StringComparison.OrdinalIgnoreCase));

        if (book == null)
        {
            return NotFound();
        }

        return book;
    }
}


