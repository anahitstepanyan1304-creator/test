﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace ApiLab;

public class RegisterRequest
{
    [Required]
    [StringLength(20, MinimumLength = 2)]
    public string Name { get; set; } = "";
 
    [EmailAddress]
    public string Email { get; set; } = "";
 
    [Range(18, 99)]
    public int Age { get; set; }
 
    [RegularExpression("^[A-Z]{3}$")]
    public string Code { get; set; } = "";
}

[Route("api/[controller]")]
public class MembersController : ControllerBase
{
    [HttpPost]
    public IActionResult Register([FromBody] RegisterRequest request)
    {
        Console.WriteLine("Action called");

        return Ok(new
        {
            IsValid = ModelState.IsValid
        });
    }
}
